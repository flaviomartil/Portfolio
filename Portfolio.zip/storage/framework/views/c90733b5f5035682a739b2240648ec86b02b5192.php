Esse e-mail foi enviado do meu Portfolio (Flávio Martil)
Remetente: <?php echo e($remetente); ?>

Asssunto: <?php echo e($assunto); ?>

Mensagem: <?php echo e($mensagem); ?>

