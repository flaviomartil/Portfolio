<img src="https://miro.medium.com/max/700/1*QckeZGe8uhX5Hkx0N8HmTg.png">
<h1>Portfolio feito em Laravel</h1>


## Sobre o projeto
Foi feito em Laravel para uso pessoal, porém foi pensado que é um portfolio para um cliente, o que significa que pode ser totalmente costumizado pelo painel de admin.
Sendo que esse fica oculto, devido a não ser interessante ter um botão de login em um portfolio.
Podem ser adicionados: Projetos,Experiências ou alterar informações.
Podemos também fazer o envio de e-mails para contatar o responsavel pelo site.

