<?php
echo '
<link href="fontawesome.min.css" rel="stylesheet">
<link href="theme.css" rel="stylesheet">

<!-- Custom styles -->
<link rel="stylesheet" href="google.css">
<section class="resume-section p-3 p-lg-5 d-flex flex-column" id="skills">
    <div class="my-auto">
    <style>
    html {
        background-color: #82a43a;
      }
    </style>
    <div class="my-auto">
    <h2 class="mb-5">Habiilidades</h2>

    <div class="subheading mb-3">Linguagens de Programação &amp; Ferramentas</div>
    <ul class="list-inline dev-icons">
        <li class="list-inline-item" title="HTML5">
            <i class="fab fa-html5"></i>
        </li>
        <li class="list-inline-item" title="CSS3">
            <i class="fab fa-css3-alt"></i>
        </li>
        <li class="list-inline-item" title="JAVASCRIPT">
            <i class="fab fa-js-square"></i>
        </li>
        <li class="list-inline-item" title="PHP">
            <i class="fab fa-php"></i>
        </li>
        <li class="list-inline-item" title="LARAVEL">
            <i class="fab fa-laravel"></i>
        </li>
        <li class="list-inline-item" title="LINUX">
            <i class="fab fa-linux"></i>
        </li>
        <li class="list-inline-item" title="AMAZON AWS">
            <i class="fab fa-aws"></i>
        </li>
    </ul>

    <div class="subheading mb-3">Fluxo de trabalho</div>
    <ul class="fa-ul mb-0">

        <li>
            <i class="fa-li fa fa-check"></i>
            Teste em Navegadores &amp; Depuração</li>
        <li>
            <i class="fa-li fa fa-check"></i>
            Equipes Multifuncionais</li>
        <li>
            <i class="fa-li fa fa-check"></i>
            Desenvolvimento Ágil com Scrum/ITIL</li>
    </ul>
</div>';